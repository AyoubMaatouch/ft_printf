# ft_printf_tester
sh run.sh
